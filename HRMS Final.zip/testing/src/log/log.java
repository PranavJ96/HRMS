package log;

public class log {
	public static int userId;
	public static int adminId;
}
